
XYRA WEBSITE
============

PAGES
-----

index.html
Homepage and brand introduction.

how-it-works.html
Explains the intended local discovery experience.

nearby-offers.html
Landing page for nearby stores, local offers and shopping deals.

for-businesses.html
Information for shops, cafes, retailers and local service businesses.

about.html
XYRA's mission, product direction and brand values.

faqs.html
Frequently asked questions about XYRA, location, offers and partnerships.

contact.html
Contact and early-access enquiry form preview.


SHARED ASSETS
-------------

assets/css/styles.css
Website styles, responsive layouts and animations.

assets/js/main.js
Navigation, scroll reveals, footer year and FAQ deep links.

assets/js/contact.js
Contact form validation preview.

assets/images/favicon.svg
XYRA favicon.

robots.txt
Crawler access rules and future sitemap location.

sitemap-template.xml
Sitemap template. Replace its domain placeholders before publishing.


LOCAL DEVELOPMENT
-----------------

Open the project folder in VS Code.

Use the Live Server extension to preview the website locally.

Open index.html through Live Server.

Test all navigation links and all seven pages.


BEFORE PRODUCTION LAUNCH
------------------------

1. Confirm the real production domain and HTTPS setup.

2. Add a self-referencing canonical URL to each page once
   the final URLs are known.

3. Add an absolute Open Graph image URL after creating a
   real social sharing image.

4. Publish a valid sitemap.xml with real page URLs.

5. Add the real sitemap URL to robots.txt.

6. Connect contact.js and the form to a secure backend or
   trusted form provider. The demo does not send enquiries.

7. Add a privacy policy and terms page before collecting
   personal information.

8. Verify all pages, links, headings and metadata.

9. Test responsive layouts and keyboard accessibility.

10. Run Lighthouse and check performance, accessibility,
    best practices and SEO.

11. Configure Google Search Console and submit the sitemap
    after the site is publicly available.

12. Make sure the published content accurately describes
    the product features that are actually available.


SEO NOTES
---------

Each page has its own title and meta description.

Keywords are included naturally in relevant headings and
visible copy.

Avoid repetitive keyword stuffing.

Do not add a meta keywords tag for Google SEO.

Rankings and Lighthouse scores cannot be guaranteed.
Use real performance tests and Search Console data
to identify further improvements.
